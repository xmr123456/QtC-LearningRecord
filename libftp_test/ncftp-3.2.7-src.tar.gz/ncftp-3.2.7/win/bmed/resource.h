//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by bmed.rc
//
#define IDD_BMED_DIALOG                 102
#define IDR_MAINFRAME                   128
#define IDD_BOOKMARK_PROPERTIES         129
#define IDC_BOOKMARK_LIST               1000
#define IDC_CONNECT                     1001
#define IDC_EDIT                        1002
#define IDC_DUPLICATE                   1003
#define IDC_NEW                         1004
#define IDC_CLOSE                       1005
#define IDC_DELETE                      1006
#define IDC_BOOKMARK_NAME               1006
#define IDC_HOSTNAME                    1007
#define IDC_USER                        1008
#define IDC_ACCOUNT                     1009
#define IDC_PASSWORD                    1010
#define IDC_REMOTE_DIR                  1011
#define IDC_LOCAL_DIR                   1012
#define IDC_BINARY                      1013
#define IDC_PORT                        1014
#define IDC_COMMENT                     1015
#define IDC_ASCII                       1018

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1014
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
