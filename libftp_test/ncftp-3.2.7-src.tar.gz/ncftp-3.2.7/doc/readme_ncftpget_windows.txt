The programs ncftpput, ncftpget, and ncftpls are
intended to be run from an existing MS-DOS Prompt
window.  It would be pointless to install a short-
cut for them, since they require parameters on
the command line which vary with each use.

The installer places the NcFTP directory in your
PATH, so you should be able to just type
"ncftpget.exe" at a prompt to see the usage, or
consult the HTML manual pages.
